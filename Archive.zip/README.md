# TerrariumPlus

Fabric worldgen mod for Minecraft 1.21.11.

## Build

- Requires Java 21
- Build: ./gradlew build
- Output: build/libs/

## Development

- Run client: ./gradlew runClient

## License

See LICENSE.
